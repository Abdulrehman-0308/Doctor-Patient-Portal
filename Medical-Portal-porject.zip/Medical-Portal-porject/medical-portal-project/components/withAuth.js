import { useSelector } from 'react-redux';
import { useRouter } from 'next/router';
import { useEffect } from 'react';

export default function withAuth(allowedRoles = []) {
  return function AuthenticatedComponent() {
}
}