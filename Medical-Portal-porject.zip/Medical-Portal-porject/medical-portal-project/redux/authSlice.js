import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  list: [],
  selectedPatient: null,
};

const patientSlice = createSlice({
  name: 'patients',
  initialState,
  reducers: {
    setPatients: (state, action) => {
      state.list = action.payload;
    },
    setSelectedPatient: (state, action) => {
      state.selectedPatient = action.payload;
    },
    addPatient: (state, action) => {
      state.list.push(action.payload);
    },
    updatePatient: (state, action) => {
      const index = state.list.findIndex(p => p.id === action.payload.id);
      if (index !== -1) {
        state.list[index] = action.payload;
      }
    },
    deletePatient: (state, action) => {
      state.list = state.list.filter(p => p.id !== action.payload);
    },
  },
});

export const { setPatients, setSelectedPatient, addPatient, updatePatient, deletePatient } = patientSlice.actions;
export default patientSlice.reducer;