import { useSelector } from 'react-redux';

export default function PatientProfile() {
  const user = useSelector((state) => state.auth.user);

  return (
    <div className="p-6">
      <h2 className="text-lg font-bold mb-4">My Profile</h2>
      <div>
        <strong>Name:</strong> {user.name}
      </div>
      <div>
        <strong>Email:</strong> {user.email}
      </div>
    </div>
  );
}