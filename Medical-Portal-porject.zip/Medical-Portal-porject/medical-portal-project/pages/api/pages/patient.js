import { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { setPatients } from '../../redux/slices/patientSlice';

export default function PatientList() {
  const dispatch = useDispatch();
  const patients = useSelector((state) => state.patients.list);

  useEffect(() => {
    const fetchPatients = async () => {
      const response = await fetch('/api/patients');
      const data = await response.json();
      dispatch(setPatients(data));
    };

    fetchPatients();
  }, [dispatch]);

  return (
    <div className="p-6">
      <h2 className="text-lg font-bold mb-4">Patient List</h2>
      <ul>
        {patients.map((patient) => (
          <li key={patient.id} className="mb-2">
            {patient.fullName}
          </li>
        ))}
      </ul>
    </div>
  );
}