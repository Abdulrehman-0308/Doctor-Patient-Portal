export default function handler(req, res) {
    const patients = [
      {
        id: 1,
        fullName: 'Jane Doe',
        email: 'jane.doe@example.com',
        phone: '1234567890',
        diagnosis: ['Flu'],
        medications: ['Paracetamol'],
        address: '123 Street',
        city: 'Some City',
        state: 'Some State',
        country: 'Some Country',
        pincode: '123456',
      },
    ];
  
    return res.status(200).json(patients);
  }