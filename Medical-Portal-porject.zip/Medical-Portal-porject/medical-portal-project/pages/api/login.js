export default function handler(req, res) {
    const { email, password } = req.body;
  
    if (email === 'doctor@example.com' && password === 'Doctor123') {
      return res.status(200).json({ user: { email, name: 'Dr. Smith' }, role: 'doctor' });
    }
  
    if (email === 'patient@example.com' && password === 'Healthcare123') {
      return res.status(200).json({ user: { email, name: 'John Doe' }, role: 'patient' });
    }
  
    return res.status(401).json({ message: 'Invalid credentials' });
  }